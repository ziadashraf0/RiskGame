
public enum Colour {
	BLUE, RED
}
