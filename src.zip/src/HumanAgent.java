import java.util.LinkedList;


public class HumanAgent implements Agent{

	@Override
	public void search(Graph map, Colour colour) {
		
	}

	@Override
	public void initializeMap(LinkedList<City> map, Colour colour) {
		
	}

	@Override
	public int extraArmies(LinkedList<City> map, Colour colour) {
		
		return 0;
	}

}
