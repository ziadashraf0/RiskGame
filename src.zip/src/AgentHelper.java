import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * Created by ziad on 11/24/19.
 */
public class AgentHelper {


    public static int calculateHeuristic(LinkedList<City> map , Colour colour) {
        int bestHeurstic=-100;
        HashMap<Integer,Integer> Heuristics = new HashMap<>();
        int counter =0;
        float ratio;

        ArrayList<Integer> visited = new ArrayList<Integer>();

        for (int i=0 ; i < map.size();i++){
            if((map.get(i).color!=colour) ){
                    counter++;

                              //ratio =(float)counter /(float) map.get(i).armies;
                    //Heuristics.put(map.get(i).ID, visited.size());
                  //  System.out.println("City ID ===>" + map.get(i).ID + " can attack ===> " + counter +"cites"+ " my armies==>" + map.get(i).armies + " Heurstic ===>" + visited.size());
                }
        }
        System.out.println("cites to conquer ====> : " + counter + " cites");
//            for (int  CityID : Heuristics.keySet())
//            {
//                int variableKey = CityID;
//                float variableValue = Heuristics.get(variableKey);
//                if (variableValue==Collections.max(Heuristics.values())){
//                    System.out.println("city with best Heurstic is ID : " + variableKey);
//                    bestHeurstic=variableKey;
//                    break;
//                }
//
//            }
return counter;
        }

}
